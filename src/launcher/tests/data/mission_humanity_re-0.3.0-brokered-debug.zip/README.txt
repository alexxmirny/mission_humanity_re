fixture brokered-debug
