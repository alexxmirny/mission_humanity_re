fixture net
