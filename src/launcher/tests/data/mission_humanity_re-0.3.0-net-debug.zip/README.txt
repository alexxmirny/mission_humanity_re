fixture net-debug
